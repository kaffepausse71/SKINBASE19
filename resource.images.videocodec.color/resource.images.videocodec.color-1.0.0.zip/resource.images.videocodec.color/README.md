# resource.images.videocodec.color
Color media flags for Kodi - VideoCodec
