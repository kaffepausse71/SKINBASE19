# resource.images.mpaa.color
Color media flags for Kodi - MPAA
