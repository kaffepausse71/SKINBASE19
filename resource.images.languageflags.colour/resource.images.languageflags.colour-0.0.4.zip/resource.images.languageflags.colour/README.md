# resource.images.languageflags.colour
