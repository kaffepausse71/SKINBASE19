# resource.images.aspectratio.color
Color media flags for Kodi - AspectRatio
