# resource.images.resolution.color
Color media flags for Kodi - Resolution
